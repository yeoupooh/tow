Your Trac password has been reset.

Here is your account information:

Login URL: <<?cs var:login.link ?>>
Username: <?cs var:account.username ?>
Password: <?cs var:account.password ?>

-- 
<?cs var:project.name ?> <<?cs var:project.url ?>>
<?cs var:project.descr ?>

