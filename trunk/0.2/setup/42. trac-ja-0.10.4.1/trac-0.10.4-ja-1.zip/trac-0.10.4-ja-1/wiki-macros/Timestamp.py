# -*- coding: UTF-8 -*-
"""現在の時刻を (秒単位で) Wiki ページに挿入する。"""

import time
def execute(hdf, txt, env):
    t = time.localtime()
    return "<b>%s</b>" % time.strftime('%c', t)
