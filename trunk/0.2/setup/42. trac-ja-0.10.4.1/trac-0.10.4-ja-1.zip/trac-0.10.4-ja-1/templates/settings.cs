<?cs include "header.cs"?>
<?cs include "macros.cs"?>

<div id="ctxtnav" class="nav"></div>

<div id="content" class="settings">

 <h1>設定とセッション管理</h1>

 <h2>ユーザ設定</h2>
 <p>
 このページでは、Tracのカスタマイズとパーソナライズ機能を提供します。
 セッションの設定はサーバに保存され、ブラウザからcookieとして送信される
 「セッションキー」によって識別されます。このcookieによって、Tracは設定をリストアします。
 </p>
 <form method="post" action="">
 <div>
  <h3>個人情報</h3>
  <div>
   <input type="hidden" name="action" value="save" />
   <label for="name">名前:</label>
   <input type="text" id="name" name="name" class="textwidget" size="30"
          value="<?cs var:settings.name ?>" />
  </div>
  <div>
   <label for="email">メールアドレス:</label>
   <input type="text" id="email" name="email" class="textwidget" size="30"
          value="<?cs var:settings.email ?>" />
  </div><?cs
  if:settings.session_id ?>
   <h3>セッション</h3>
   <div>
    <label for="newsid">セッションキー:</label>
    <input type="text" id="newsid" name="newsid" class="textwidget" size="30"
           value="<?cs var:settings.session_id ?>" />
    <p>このセッションキーは、カスタム設定やセッション情報をサーバに保存するために
    使用されます。自動生成されたセッションキーがフォームに設定されていますが、
    他の端末やWebブラウザで同じ設定を使用する時に思い出しやすい、簡単なキーに
    変更することが出来ます。</p>
   </div><?cs
  /if ?>
  <div>
   <br />
   <input type="submit" value="保存" />
  </div >
 </div>
</form><?cs
if:settings.session_id ?>
 <hr />
 <h2>セッションの復元</h2>
 <p>以前作成したセッションをロードします。セッションキーを入力して
 「適用」ボタンをクリックしてください。複数の端末やWebブラウザで同じ設定を
 使用することが出来ます。</p>
 <form method="post" action="">
  <div>
   <input type="hidden" name="action" value="load" />
   <label for="loadsid">Existing Session Key:</label>
   <input type="text" id="loadsid" name="loadsid" class="textwidget" size="30"
          value="" />
   <input type="submit" value="適用" />
  </div>
 </form><?cs
/if ?>

</div>
<?cs include:"footer.cs"?>
